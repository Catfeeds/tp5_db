<?php
namespace app\index\controller;

use think\Request;

/***
 * 空控制器
 * Class Error
 * @package app\index\controller
 */
class Error
{
    public function index(Request $request)
    {

        //根据当前控制器名来判断要执行那个城市的操作

    }

}
<?php

namespace app\admin\controller;

use think\Controller;
use think\captcha\Captcha;

class About extends Controller
{
    public function index()
    {
        return $this->fetch();
    }


}

<?php

namespace app\admin\controller;

use think\Controller;
use think\captcha\Captcha;

class Link extends Controller
{
    /***
     * 链接
     * @return mixed
     */
    public function index()
{
    return $this->fetch();
}


}

<?php
namespace app\index\controller\login;

use app\model\Demo;
use think\Controller;

class Index extends Controller
{
    public function index()
    {
        $M = new Demo();
        $M->index();return;
//        return $this->fetch();
    }
}
